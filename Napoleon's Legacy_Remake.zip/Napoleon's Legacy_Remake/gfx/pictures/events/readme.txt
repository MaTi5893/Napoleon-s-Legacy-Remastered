ashes.tga = debate.tga
austflag.tga = farming.tga
chicagofire.tga = xinhai.tga
this overwrites vanilla event pictures, meaning the game doesn't have to load them (faster startup)
mining is already a vanilla event picture